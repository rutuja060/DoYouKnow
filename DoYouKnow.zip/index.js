var readlineSync=require('readline-sync');
const chalk = require('chalk');
const log = console.log;
var userName = readlineSync.question('What is your name? ');
var score=0;
console.log(('Welcome to the quiz ') + userName);


var userReply= readlineSync.question('Do you know Rutuja? ');
console.log("Great");

console.log("The quiz consists of 5 questions\nFor each correct answer you get +1\nFor each wrong answer you get -1.\nLet's Begin!  ")


function play(question,answer)
{
  var userAnswer=readlineSync.question(question)
  if (userAnswer===answer)
  {
    console.log("Yay! You are RIGHT!");
    score=score+1;
  }
  else{
    console.log("Oops, You are wrong!");
    score=score-1;
  }
 console.log("Current score is",score);
 console.log("___________________");
}
 


var questions=[
{
 question:`
 Her fav TV show?
 a:How I Met Your Mother
 b:FRIENDS
 c:Brooklyn Nine-Nine \n`,
  answer:"b"
},
{
		question: `
	If given choice what will She choose?
	a: Go Sky Diving
	b: Go Bungee Jumping \n`,
		answer: "a"
	},
  {
		question: `
	Her Fav Bollywood Actor?
	 a: Rajkumar Rao
	 b: Ranveer Singh
   c: Vicky Kaushal \n`,
		answer: "b"
	},
  {
		question: `
	Her comfort food?
	 a: Chicken Biryani
	 b: Maggi
   c: Pizza \n`,
		answer: "a"
	},
  {
		question: `
	Her fav animal?
	 a: Koala
	 b: Elephant
   c: Dog
   d: Cat \n`,
		answer: "c"
	}




 

];

for(i=0;i<questions.length;i++){
  var currentQuestions=questions[i];
  play(currentQuestions.question,currentQuestions.answer)

}
console.log("You Scored ",score)








